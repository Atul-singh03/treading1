package com.atul.config;

public class JwtConstant {

    public static final String SECRETE_KEY = "SDUFNSODVUCWBEDSAUOCDBFQEUOASDFCHDAWFWEF;io";

    public static final String JWT_HEADER ="Authorization";


}
