package com.atul.domain;

public enum VerificationType {

    MOBILE,
    EMAIL


}
