package com.atul.repository;

import com.atul.domain.USER_ROLE;
import com.atul.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmail(String email);

}
