package com.atul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
